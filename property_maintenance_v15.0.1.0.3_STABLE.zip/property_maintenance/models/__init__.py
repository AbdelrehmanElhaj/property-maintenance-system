# -*- coding: utf-8 -*-

from . import res_partner
from . import maintenance_category
from . import maintenance_stage
from . import property
from . import building
from . import unit
from . import asset
from . import maintenance_request
from . import work_order
from . import preventive_maintenance
from . import maintenance_team
from . import technician
from . import contractor
from . import maintenance_cost_line
